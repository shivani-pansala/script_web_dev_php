<?php
$name= "shivani";
$age= 20;
   echo "My name is  ".$name ."  i am " .   $age. "  years old  "
?>