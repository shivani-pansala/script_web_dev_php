<?php
$text = "shivani";
 echo strlen($text);
?>