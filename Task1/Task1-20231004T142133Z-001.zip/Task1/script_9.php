<?php
$dd = 01;
$mon = 03;
$yyyy = 2003;
  echo "$dd/$mon/$yyyy"; 
?>