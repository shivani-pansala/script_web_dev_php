<?php
$num= 6;
  if ($num %2 == 0)
  { 
    echo "this is even";
  }
  else
  {
	echo "this is odd";
  }
?>