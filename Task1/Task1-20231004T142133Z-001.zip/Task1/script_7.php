<?php
$x = 5;
$y = $x;
  echo $y;
?>