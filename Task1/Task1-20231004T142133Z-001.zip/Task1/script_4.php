<?php
   echo " Hello ". " php ";
?>